setTimeout(function(){
    console.log("Saya dijalankan Belakangan")
    },3000)
    console.log("Saya dijalankan Terlebih Dahulu")