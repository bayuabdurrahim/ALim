var x = 5;
var y = 6;
var z = x + y;
console.log(z)