var sayHELLO ="Halo world"
console.log(sayHELLO)

